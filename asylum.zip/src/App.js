import "./App.css";
import { Route,Routes } from "react-router-dom";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Main from "./pages/Main";
import Mint from "./pages/Mint";
import Story from './pages/Story';
import Desktop from "./pages/Desktop"
import Desktop2 from "./pages/Desktop2"

function App() {
  return (
    <div>
      <Header />
      <Routes>
        <Route path="/" element={<Main />}/>
        <Route path="/story" element={<Story/>}/>
        <Route path="/mint" element={<Mint/>}/>
        <Route path="/desktop" element={<Desktop/>}/>
        <Route path="/desktop2" element={<Desktop2/>}/>
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
