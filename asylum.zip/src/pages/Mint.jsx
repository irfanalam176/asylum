import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import banner from "../assets/img/banner.png";
import crown from "../assets/img/crown.png";
import coin1 from "../assets/img/coin-1.png";
import coin2 from "../assets/img/coin-2.png";
import coin3 from "../assets/img/coin-3.png";
import eliteText from "../assets/img/eliteText.svg";
import asylumLogo from "../assets/img/asylumLogo.svg";
// import circle from "../assets/img/pathCircle.svg";
import DragableElements from "../components/Range";
export default function Mint() {
  return (
    <div>
      <Container>
        <div className="outerContainer mintPage">
          <div className="bannerContainer">
            <img src={banner} alt="" className="banner" />
          </div>
          <div className="purchaseCard">
            <div className="coins">
              <a href="/"><img src={coin1} alt="" /></a>
              <a href="/"><img src={coin2} alt="" /></a>
              <a href="/"><img src={coin3} alt="" /></a>
            </div>

            <img src={asylumLogo} alt="" className="asylumLogo" />

            <div className="amount">
              <div className="d-flex align-items-center gap-5">
                <button>
                  <span>+</span>
                </button>
                <span>0</span>
                <button>
                  <span>-</span>
                </button>
              </div>

              <a href="/" className="mainBtn">
                PURCHASE
              </a>
              <h6>10 PER TRANSACTION</h6>
            </div>
          </div>

          <div className="pathSection">
            <div className="pathContainer">
              <span className="path green">rebels</span>
              <span className="path purple">survivors</span>
              <span className="path">keepers</span>
            </div>
            {/* <div className="pathGraphHolder">
              <div className="pathGraph">
                <img src={circle} alt="" />
                <img src={circle} alt="" />
                <img src={circle} alt="" />
              </div>
            </div> */}

            {/* range start */}
            <div className="px-lg-4"><DragableElements /></div>
            {/* range end */}

            <Row>
              <Col lg={7} className="mx-auto">
                <div className="text-center">
                  <h1>CHOOSE YOUR PATH</h1>
                  <h5 className="path green">rebels</h5>
                  <p>
                    1 Xeta card<br></br>
                    Life span 1 year<br></br>
                    Survival packs 4(compounding yield)
                  </p>
                  <h5 className="path purple">survivors</h5>
                  <p>
                    5 Xeta cards<br></br>
                    Life span 2 years<br></br>
                    Survival packs 8(compounding yield)
                  </p>
                  <h5 className="path">keepers</h5>
                  <p>
                    10 Xeta cards<br></br>
                    Life span 3 years<br></br>
                    Survival packs 12(compounding yield)
                  </p>
                </div>
              </Col>
            </Row>
          </div>

          <Row>
            <Col lg={8} className="mx-auto">
              <div className="eliteCard">
                <img src={crown} alt="" />
                <div>
                  <img src={eliteText} alt="" className="eliteImg" />
                  <span>25</span>
                </div>
                <img src={crown} alt="" />
              </div>
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
}
