import React from "react";
import { Col, Container,Row } from "react-bootstrap";
import logo from "../assets/img/logo.png";
import power from "../assets/img/power.png";
import spnsors from "../assets/img/sponsors.png";
import { Link } from "react-router-dom";
export default function Main() {
  return (
    <div>
      <Container>
        <div className="outerContainer">
          <div className="innerContainer mainPage">
            <div>
            <img src={logo} alt="" className="logo"/>
            <h4>presents</h4>
            <div >
              <h3 >DEFI</h3>
              <h1>ASYLUM</h1>
            </div>
            <p className="mainText">
              “A DISTOPIAN WORLD PLAGUED BY<br></br>CHAOS AND DISPAiR”
            </p>
            </div>

            <Link to={"/story"} className="mainBtn">ENTER</Link>

            <div>
            <Row>
                <Col lg={6} className="mx-auto">
                    <div className="d-flex align-items-center justify-content-between px-2 p-lg-0">
                        <img src={logo} alt="" className="smLogo"/>
                        <img src={power} alt="" className="poweredBy"/>
                    </div>
                </Col>
            </Row>
            <Row>
                <Col lg={7} className="mx-auto my-3">
                   <img src={spnsors} alt="" className="sponsors"/>
                </Col>
            </Row>
            <Row>
                <Col lg={10} className="mx-auto">
                  <p className="smText px-2 p-lg-0">
                  NOT FINANCIAL ADVICE<br></br>
The information provided does not constitute investment advice, financial advice, trading advice, or any other advice. TheMOOV Digital, LTD documentation, website, DApp, social media, and marketing materials do not consider your particular financial objectives, financial situation, or needs and are not intended to be construed as a recommendation for action on your part. TheMOOV Digital, LTD cannot guarantee any returns or price action and is subject to overall market conditions. TheMOOV Digital, LTD accepts no liability for damages, whether consequential or indirect, of any kind arising from the use, reference, or reliance on the information provided. Please conduct your due diligence and participate wisely.
                  </p>
                </Col>
            </Row>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}
