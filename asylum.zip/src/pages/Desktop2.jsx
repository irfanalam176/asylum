import React from 'react'
import DeskTopCard from '../components/DeskTopCard'
import card1 from "../assets/img/pathCard1.png"
import card3 from "../assets/img/pathCard2.png"
import card2 from "../assets/img/pathCard3.png"
import CheckBox from '../components/CheckBox'
import { Container } from 'react-bootstrap'
export default function Desktop2() {
  return (
    <div className='desktopPage2'>
      <Container>
      <div className="outerContainer">
            <div className="innerContainer">
                    <DeskTopCard props={{title:"REBEL",img:card1,color:"orange",est:"est;",checkBoxes:[
                    <CheckBox props={{id:"chk1",name:"chk1"}}/>,<CheckBox props={{id:"chk2",name:"chk2"}}/>,
                    <CheckBox props={{id:"chk3",name:"chk3"}}/>,<CheckBox props={{id:"chk4",name:"chk4"}}/>
                  ]}}/>
                    <DeskTopCard props={{title:"SURVIVORS",odd:true,color:"green",img:card2,checkBoxes:[
                    <CheckBox props={{id:"chk5",name:"chk5"}}/>,<CheckBox props={{id:"chk6",name:"chk6"}}/>,
                    <CheckBox props={{id:"chk7",name:"chk7"}}/>,<CheckBox props={{id:"chk8",name:"chk8"}}/>,
                    <CheckBox props={{id:"chk9",name:"chk9"}}/>,<CheckBox props={{id:"chk10",name:"chk10"}}/>,
                    <CheckBox props={{id:"chk11",name:"chk11"}}/>,
                    <CheckBox props={{id:"chk12",name:"chk12"}}/>,
                    ]}}/>
                    <DeskTopCard props={{title:"KEEPERS",img:card3,color:"black",checkBoxes:[
                    <CheckBox props={{id:"chk13",name:"chk13"}}/>,<CheckBox props={{id:"chk14",name:"chk14"}}/>,
                    <CheckBox props={{id:"chk15",name:"chk15"}}/>,<CheckBox props={{id:"chk16",name:"chk16"}}/>,
                    <CheckBox props={{id:"chk17",name:"chk17"}}/>,<CheckBox props={{id:"chk18",name:"chk18"}}/>,
                    <CheckBox props={{id:"chk19",name:"chk19"}}/>,<CheckBox props={{id:"chk20",name:"chk20"}}/>,
                    <CheckBox props={{id:"chk21",name:"chk21"}}/>,<CheckBox props={{id:"chk22",name:"chk22"}}/>,
                    <CheckBox props={{id:"chk23",name:"chk23"}}/>,<CheckBox props={{id:"chk24",name:"chk24"}}/>,
                    ]}}/>
            </div>
        </div>
      </Container>
    </div>
  )
}
