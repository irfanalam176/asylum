import React from 'react'
import { Container,Col,Row } from 'react-bootstrap'
import banner from "../assets/img/banner-2.png"
import card1 from "../assets/img/card-1.png"
import card2 from "../assets/img/card-2.png"
import card3 from "../assets/img/card-3.png"
export default function Desktop() {
  return (
    <div className='deskTopPage'>
        <Container>
            <div className="outerContainer desktop">
            <div className="bannerContainer">
          <img src={banner} alt="" className="banner" />
            </div>
            </div>

            <div className="cardSection">
                <Row>
                    <Col className='col-lg-1 d-none d-lg-block'></Col>
                    <Col  className='my-lg-auto col-4 col-lg-3'>
                        <img src={card1} alt="" />
                    </Col>
                    <Col className='col-4'>
                        <img src={card2} alt="" />
                    </Col>
                    <Col  className='my-lg-auto col-4 col-lg-3'>
                        <img src={card3} alt="" />
                    </Col>
                    <Col className='col-lg-1'></Col>
                </Row>
            </div>
        </Container>
    </div>
  )
}
