import React from 'react'
import { Container,Row,Col } from 'react-bootstrap'
import poster from "../assets/img/poster2.png"
import asylumLogo from "../assets/img/asylumLogo.svg"
import { Link } from 'react-router-dom'
export default function Story() {
  return (
    <div>
        <Container>
            <div className="outerContainer">
                <div className="innerContainer storyPage">
                    <Row>
                        <Col lg={8} className="mx-auto text-center col-10 col-lg-8">
                        <img src={asylumLogo} alt="" className='asylumLogo'/>
                        <img src={poster} alt="" className='poster2 '/>
                        <p className="mainText">
                        In a world ravaged by chaos and despair, a place called Asylum emerged as the last flickering beacon of hope. Asylum, a haven amidst the ruins, sheltered those who refused to succumb to the perils of the dystopian landscape. Within its fortified walls, a unique society had formed, divided into three distinct factions: rebels, survivors, and Keepers.
                        </p>

                        <p className="mainText green">
                        The rebels are the daring souls who defied the oppressive forces that sought to control them. They were the firebrands, the ones who questioned authority, and tirelessly fought for freedom. Braving the treacherous wastelands outside, rebels had learned to adapt and thrive in the harshest conditions.
                        </p>

                        <p className="mainText purple">
                        Survivors are the resourceful ones, those who had weathered the storm and managed to carve out a semblance of stability in this desolate world. They had developed the skills necessary to scavenge, build, and endure. Their resilience made them invaluable members of the community, contributing to the collective survival of Asylum.
                        </p>

                        <p className="mainText gray">
                        At the pinnacle of this society stood the Keepers, the elite protectors of Asylum. These individuals are the epitome of strength, skill, and courage. Equipped with advanced weaponry and tactical knowledge, they safeguarded the walls from any external threats. The  Keepers were revered, their presence instilling a sense of security and hope in the hearts of the Asylum residents.
                        </p>

                        <p className="mainText">
                        Every three months, the inhabitants of Asylum received a vital lifeline—aerial deliveries known as survival pacts. These packs contained essential supplies and resources crucial for their survival in this unforgiving world. The rebels received four pacts, the survivors were allotted eight, and the Keepers, the highest tier, were bestowed with the complete set of twelve survival pacts.
                        </p>

                        <p className="mainText">
                        The significance of these survival packs extended beyond immediate sustenance. As time passed, the pacts compounded, becoming increasingly valuable. Their contents grew more advanced, granting the recipients an edge in the struggle for survival. The rebels saw these pacts as opportunities to challenge the status quo, the survivors utilized them to fortify their communities, and the Keepers sought to maintain their position as the guardians of Asylum.
                        </p>

                        <p className="mainText">
                        Within the walls of Asylum, the tension between factions simmered, as each group pursued their own agenda. Yet, they all shared a common goal—to persevere against the ravages of a bleak and uncertain future. As the survival pacts continued to arrive, the fate of Asylum hung in the balance, its inhabitants relying on their wits, skills, and the ever-growing power of these lifelines to shape their destinies in this futuristic realm. 
                        </p>
                    <Link to={"/mint"} className="mainBtn">choose your path</Link>
                        </Col>
                    </Row>

                </div>
            </div>
        </Container>
    </div>
  )
}
