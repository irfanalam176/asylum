import React from 'react'

export default function CheckBox({props}) {
    let {id,name} = props
    console.log(id);
    return (
        <div>
          
                <input type="checkbox" id={`${id}`} name={`${name}`}/>
                <label htmlFor={`${id}`} className='chkboxLable'></label>
        </div>
    )
}
