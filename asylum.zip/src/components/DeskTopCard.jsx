import React from 'react'

import { Row, Col } from 'react-bootstrap'
// import CheckBox from './CheckBox'

export default function DeskTopCard({ props }) {
        let checkBoxes=props.checkBoxes
    return (
        <div className='desktopCard text-center'>
            <Row className={props.odd && "flex-row-reverse"}>
                <Col sm={6} >
                    <div className={`cardImgBox ${props.odd&&"ms-lg-auto"}`}>
                        <div className="imgContainer">
                            <img src={props.img} alt="" className='w-100' />
                        </div>
                    </div>
                </Col>
                <Col lg={1}></Col>
                <Col sm={5}>
                    <h1 className={`path ${props.color}`}>{props.title}</h1>
                    <p>
                        1 Xeta card<br></br>
                        Life span 1 year<br></br>
                        Survival packs 4(compounding value)
                    </p>

                    <div className="pack">
                        SURVIVAL PACK<br></br>
                        <span>DELIVERY</span>
                    </div>

                    <Row>
                        <Col lg={8} className='mx-auto'>
                          <div className="inputContainer">
                           {
                               checkBoxes
                           }
                          </div>
                           
                        </Col>
                    </Row>
                    <Row>
                        <Col className='col-11 mx-auto text-start'>
                            <span className='est'>{props.est}</span>
                        </Col>
                    </Row>
                </Col>
            </Row>
        </div>
    )
}
