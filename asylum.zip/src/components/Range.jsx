import React, { useState } from 'react';
import { Range } from 'react-range';

const DragableElements = () => {
  const [values, setValues] = useState([0, 50, 100]);

  const handleChange = (newValues) => {
    setValues(newValues);
  };

  return (
    <div className='range'>
      <Range
        values={values}
        min={0}
        max={100}
        step={1}
        onChange={handleChange}
        renderTrack={({ props, children }) => (
          <div
            {...props}
            style={{
              ...props.style,
              height: '6px',
              width: '100%',
              backgroundColor: '#ccc',
              borderRadius: '3px',
              marginTop: '10px',
            }}
          >
            {children}
          </div>
        )}
        renderThumb={({ props }) => (
          <div
            {...props}
            style={{
              ...props.style,
              height: '20px',
              width: '20px',
              backgroundColor: '#999',
              borderRadius: '50%',
              cursor: 'grab',
              outline: 'none',
            }}
          />
        )}
      />
    </div>
  );
};

export default DragableElements;
