import React from 'react'
import plusIcon from "../assets/img/plusIcon.png"
import twitter from "../assets/img/twitter.svg"
import discord from "../assets/img/discord.svg"
import gitbook from "../assets/img/gitbook.svg"
import { Container } from 'react-bootstrap'
export default function Footer() {
  return (
      <Container>
    <div className='footer'>
     <div className="">
     <div className="footerLinks">
        <a href="/"><img src={twitter} alt="" /></a>
        <a href="/"><img src={discord} alt="" /></a>
        <a href="/"><img src={gitbook} alt="" /></a>
      </div>
        <div className='d-flex align-items-center justify-content-center gap-2'>
        <span>POWERED</span><img src={plusIcon} alt="" /><span>BY XETA</span>
        </div>
     </div>
    </div>
      </Container>
  )
}
